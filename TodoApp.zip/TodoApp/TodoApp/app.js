const express = require('express');
const app = express();

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

let tasks = [
  { id: 1, title: "Prepare Weekly Report", description: "Complete and submit the weekly project status report", priority: "High", status: "In Progress" },
  { id: 2, title: "Fix Login Bug", description: "Resolve the authentication issue on the login page", priority: "High", status: "Pending" },
  { id: 3, title: "Update Documentation", description: "Update the API documentation with new endpoints", priority: "Medium", status: "Completed" },
  { id: 4, title: "Design Review Meeting", description: "Attend UI/UX design review session with the team", priority: "Medium", status: "Pending" },
  { id: 5, title: "Database Optimization", description: "Optimize slow queries on the user analytics table", priority: "Low", status: "Pending" },
];
let nextId = 6;

// Dashboard
app.get('/', (req, res) => {
  const total = tasks.length;
  const pending = tasks.filter(t => t.status === 'Pending').length;
  const inProgress = tasks.filter(t => t.status === 'In Progress').length;
  const completed = tasks.filter(t => t.status === 'Completed').length;
  res.render('dashboard', { tasks, total, pending, inProgress, completed, message: req.query.message || null });
});

// Add Task - GET
app.get('/add', (req, res) => {
  res.render('add-task', { error: null });
});

// Add Task - POST
app.post('/add', (req, res) => {
  const { title, description, priority } = req.body;
  if (!title || !description || !priority) {
    return res.render('add-task', { error: 'All fields are required.' });
  }
  tasks.push({ id: nextId++, title, description, priority, status: 'Pending' });
  res.redirect('/?message=Task+added+successfully!');
});

// Edit Task - GET
app.get('/edit/:id', (req, res) => {
  const task = tasks.find(t => t.id === parseInt(req.params.id));
  if (!task) return res.redirect('/');
  res.render('edit-task', { task, error: null });
});

// Edit Task - POST
app.post('/edit/:id', (req, res) => {
  const { title, description, priority } = req.body;
  if (!title || !description || !priority) {
    const task = tasks.find(t => t.id === parseInt(req.params.id));
    return res.render('edit-task', { task, error: 'All fields are required.' });
  }
  const idx = tasks.findIndex(t => t.id === parseInt(req.params.id));
  if (idx !== -1) {
    tasks[idx] = { ...tasks[idx], title, description, priority };
  }
  res.redirect('/?message=Task+updated+successfully!');
});

// Delete Task
app.post('/delete/:id', (req, res) => {
  tasks = tasks.filter(t => t.id !== parseInt(req.params.id));
  res.redirect('/?message=Task+deleted.');
});

// Change Status
app.post('/status/:id', (req, res) => {
  const task = tasks.find(t => t.id === parseInt(req.params.id));
  if (task) {
    const flow = ['Pending', 'In Progress', 'Completed'];
    const current = flow.indexOf(task.status);
    task.status = flow[(current + 1) % flow.length];
  }
  res.redirect('/?message=Status+updated!');
});

app.listen(8001, () => console.log('Server running on http://localhost:8001'));
